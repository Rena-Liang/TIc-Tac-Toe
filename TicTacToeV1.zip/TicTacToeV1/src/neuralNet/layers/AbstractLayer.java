/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuralNet.layers;

import neuralNet.neurons.Neuron;

/**
 *
 * @author liang_882891
 */
public abstract class AbstractLayer {
    private int numberOfNeurons;
    
    public void initialize (int numOfNeurons){
        numberOfNeurons = numOfNeurons;
        initializeSubClasses();
    }
    
    public int getNumberOfNeurons(){
        return numberOfNeurons;
    }
    
    abstract void initializeSubClasses();
    
    abstract Neuron getNeuron(int num);
}
