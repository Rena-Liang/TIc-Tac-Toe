/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuralNet.layers;

import java.util.ArrayList;
import java.util.List;
import neuralNet.neurons.Neuron;
import neuralNet.neurons.OutputNeuron;

/**
 *
 * @author liang_882891
 */
public class OutputLayer extends AbstractLayer{
    
    private List<OutputNeuron> outputNeurons;
    
    @Override
    public void initializeSubClasses(){
        outputNeurons = new ArrayList<>();
        for (int i = 0; i < getNumberOfNeurons(); i++){
            OutputNeuron n = new OutputNeuron();
            // n.initialize(i,9,1);
            outputNeurons.add(n);
        }
    }
    
    @Override
    public Neuron getNeuron(int num){
        return outputNeurons.get(num);
    }
}
